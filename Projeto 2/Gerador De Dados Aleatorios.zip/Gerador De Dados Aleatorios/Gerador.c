/*
 ***Programa: Gerados de Dados Aleatórios
 ***Função: Gerar dados aleatórios para planilhas
 ***Autores: Prof.Chidambaram Chidambaram, Wyllen Brito da Silva (BCC)
 ***Descrição: O programa Gerador de Dados Aleatórios para planilhas foi desenvolvido através do PROJETO DE ENSINO
            "Análise de dados e Construção de Sistemas de apoio a decisão utilizando
             planilhas eletrônicas e ferramentas de mercado"

 ***Departamento: Engenharia de Produção e Sistemas-DEPS-UDESC-JOINVILLE
 ***DATA DE CONCLUSÃO: 01 DE DEZEMBRO DE 2022
*/

/*
    Observações sobre o código:
    Data de nascimento: de 1927 até 2010
    Idade (somente): de 1 até 100 anos  

    A quantidade de linhas (registros) que podem ser geradas
    sem erros com testes realizados é de até 10.000 linhas.
    Mais do que isso pode (ou não) ocorrer erros.

    Para geração de valores que estao em arquivo (como nome, cidade, estado, etc),
    tende-se a demorar mais. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <time.h>

#define NUMESCOLHAS 15 //constante (não alterar)
#define TamvectAleatorios NUMESCOLHAS*3 //3 eh o numero de possibilidades que existe no vetor de numAleatorios. (não alterar)
//tamvectaleatorios = 45 (não alterar)

//Prototipacao das funcoes:
int* cpf_generator();
void menuGerador();
void Finaliza(int VetorDeEscolhas[],int VetorNumAleatorios[]);
void TelefoneAleatorio(FILE * ArquivoSalmento);
void dataDeNascimentoAleatoria(FILE * ArquivoSalmento,int opcao);
int NumerosAleatorios(FILE *arquiSalvamento,int opcao,int VetorNumAleatorios[],int contador,int w);
char * CidEstadoRegiao(char Frase[100],int op);
void escolheAleatorioArquivo(FILE *arquivo,FILE *arquivoSalvamento, int opcao,int valor);
int NumeroRandom(int min, int max);
void shuffle(int *array,int min,int max);
int confirmarAcao() ;
int anoAtual();

void menuGerador() {
    int escolhas[NUMESCOLHAS] = {0};
    int vetorNumAleatorios[TamvectAleatorios] = {0};

    int IntervaloInicial;
    int IntervaloFinal;
    
    int len = 0;
    int op;
    int i=0;
    int z= 0;
    do{
        printf("\n ------- GERADOR DE VALORES ALEATORIOS -------- \n\n");
        printf("[1] Gerar Nomes Aleatorios \n");
        printf("[2] Gerar Telefones Aleatorios \n");
        printf("[3] Gerar Data de Nascimento ou Idade Aleatorios \n");
        printf("[4] Gerar CPF's Aleatorios \n");
        printf("[5] Gerar Numeros Aleatorios \n");
        printf("[6] Gerar Cidades/Estados/Regioes do Brasil Aleatorias \n");
        printf("[0] Imprimir Itens escolhidos e Finalizar\n");
        printf("Escolha uma Opcao:\n");
        fflush(stdin);
        scanf("%d", &op);
        fflush(stdin);

        switch (op){
            case 1:
                do {
                    fflush(stdin);
                    printf("\nEscolha apenas uma opcao: \n");
                    printf("[1] Gerar somente Nome\n");
                    printf("[2] Gerar Nome e Sobrenome\n");
                    printf("[3] Gerar Nome Completo\n");
                    scanf("%d", &op);
                    fflush(stdin);
                    
                } while (op<1 || op>3);
                escolhas[i] = op;
                i++;
                break;
            case 2: 
                op = 4;
                escolhas[i] = op;
                i++;
                break;
            case 3: 
                do {
                    printf("\nEscolha apenas uma opcao: \n");
                    printf("[1] Gerar Data de Nascimento (Somente)\n");
                    printf("[2] Gerar Idade (Somente)\n");
                    printf("[3] Gerar Data de Nascimento e Idade\n");
                    scanf("%d", &op);
                    if(op<1 || op>3) {
                        printf("%d nao eh opcao. Digite uma opcao valida \n",op);
                    }
                } while (op<1 || op>3);

                if(op==1){
                    op = 5;
                } 
                
                if(op==2) {
                    op = 6;
                }

                if(op==3) {
                    op = 14;
                }
                escolhas[i] = op;
                i++;
                break;
            case 4: 

                op = 7; //CPF
                escolhas[i] = op;
                i++; 
                break;
            case 5:

                printf("Qual o intervalo de numeros aleatorios voce deseja?");
                printf("\nIntervalo Inicial: ");
                scanf("%d",&IntervaloInicial);
                printf("\nIntervalo Final: ");
                scanf("%d",&IntervaloFinal);

                printf("Gerar Numero com casas decimais? \n");
                do {
                    printf("[1] Sim\n");
                    printf("[2] Nao\n");
                    scanf("%d", &op);
                    if(op<1 || op>2) {
                        printf("%d nao eh opcao. Digite uma opcao valida \n",op);
                    }
                } while (op<1 || op>2);

                if (op==1) {
                    printf("Escolha uma opcao para quantidade de casas decimais: \n");
                    do {
                        printf("[1] Uma Casa Decimal\n");
                        printf("[2] Duas Casas Decimais\n");
                        scanf("%d", &op);
                        if(op<1 || op>2) {
                            printf("%d nao eh opcao. Digite uma opcao valida \n",op);
                        }
                    } while (op<1 || op>2);
                    
                    vetorNumAleatorios[z] = op;
                } else {
                    vetorNumAleatorios[z] = 3;
                }

                op = 8;
                escolhas[i] = op;
                
                z++;
                vetorNumAleatorios[z] = IntervaloInicial;
                z++;
                vetorNumAleatorios[z] = IntervaloFinal;
                
                z++;
                i++;
                break;
            case 6: 

                do {
                    printf("Escolha uma opcao: \n");
                    printf("[1] - Cidades\n");
                    printf("[2] - Estados\n ");
                    printf("[3] - Regioes\n");
                    printf("[4] - Cidade e Estado\n");
                    printf("[5] - Cidade, Estado e Regiao\n");
                    scanf("%d", &op);
                    if(op<1 || op>5) {
                        printf("%d nao eh opcao. Digite uma opcao valida \n",op);
                    }
                } while (op<1 || op>5);

                switch (op) {
                    case 1:
                        escolhas[i] = 9; // 9 --> Cidade
                        i++;
                        break;
                    case 2:
                        escolhas[i] = 10; // 10 -> Estados
                        i++;
                        break;
                    case 3:
                        escolhas[i] = 11; // 11 -> Regioes
                        i++;
                        break;
                    case 4:
                        escolhas[i] = 12; // 12 -> Cidades e Estados
                        i++;
                        break;
                    case 5:
                        escolhas[i] = 13; // 13 -> Cidades, Estados e Regiões.
                        i++;
                    default:
                        break;
                }

                break;
            case 0: 
                Finaliza(escolhas,vetorNumAleatorios);
                return;
                break;
            default:printf("\nOpcao Invalida\n");
                break;
        }
        
        /*
        printf("\n\n\n");
        printf("Opcoes Escolhidas ate o momento:");
        for(int k=0;k<NUMESCOLHAS;k++) {
            if(escolhas[k]!=0) {
                printf("%d ",escolhas[k]);
            }
        }
        printf("\n\n\n");
        */
        
        printf("\nOpcoes escolhidas ate o momento:\n");
        for(int j=0;j<NUMESCOLHAS;j++) {

            if(escolhas[j]!=0) {
                
                switch (escolhas[j]) {
                    case 1:
                        printf("Nome");
                        break;
                    case 2:
                        printf("Nome e Sobrenome");
                        break;
                    case 3:
                        printf("Nome Completo");
                        break;
                    case 4:
                        printf("Telefone");
                        break;
                    case 5:
                        printf("Data de Nascimento");
                        break;
                    case 6:
                        printf("Idade");
                        break;
                    case 7:
                        printf("CPF");
                        break;
                    case 8:
                        printf("Numeros Aleatorios");
                        break;
                    case 9:
                        printf("Cidades");
                        break;
                    case 10:
                        printf("Estados");
                        break;
                    case 11:
                        printf("Regioes");
                        break;
                    case 12:
                        printf("Cidades e Estados");
                        break;
                    case 13:
                        printf("Cidade, Estado e Regioes");
                        break;
                    case 14:
                        printf("Data de Nascimento e Idade");
                        break;
                    default:
                        break;
                }
                printf(";");
            }
        }
        printf("\n");



        if(escolhas[NUMESCOLHAS-1]!=0) { //se o ultimo item do meu vetor for diferente de zero, quer dizer que ele excedeu o limite de opcoes
        printf("\nQuantidade de opcoes excedido.\n");
        break;
        }
    
        printf("\nQuantidade de Campos Disponiveis: %d\n", NUMESCOLHAS-i);
        
    }while(op!=0);

    Finaliza(escolhas,vetorNumAleatorios); //caso o usuario nao aperte em 0.
}

void Finaliza(int VetorDeEscolhas[],int VetorNumAleatorios[]){

    if(VetorDeEscolhas[0]==0){
        printf("Voce nao escolheu nenhum campo, encerrando o programa... ");
        return;
    }
    
    /*
    printf("Vetor de Escolhas:\n");
    for(int i=0;i<NUMESCOLHAS;i++) {
        printf("%d ",VetorDeEscolhas[i]);
    }
    */
    
    //printf("\n\n");

    printf("\n\n\tDigite a quantidade desses valores voce quer gerar.\n");
    printf("\tExemplo: Para o valor digitado: '20'");
    printf("Serao gerados 20 itens dos campos (Nome,CPF,Idade,..) que vc escolheu\n\n");
    printf("Digite a quantidade de registros (Linhas) que voce deseja gerar: ");
    int quantidade;
    scanf("%d",&quantidade);
    printf("\n\tQuantidade de itens escolhidos: %d\n",quantidade);    
    fflush(stdin);
    int aux;
    
    if(quantidade<=0){
        printf("Voce escolheu nao gerar nenhuma quantidade, encerrando o programa... ");
        return;
    }

    
    printf("\n");
    //Arquivo de salvamento:
    FILE *ArqDadosAleatorios = fopen("ArqDadosAleatorios.txt","w+");

    if (ArqDadosAleatorios == NULL) {
        printf("Erro na abertura do arquivo de Salvamento de Dados");
        return;
    } else {
        printf("Arquivo de Salvamento de Dados Aberto com sucesso!\n");
    }

    //Arquivos para geracao de valores aleatorios
    FILE *arqNomes = fopen("ListaDeNomes.txt","r");
    FILE *arqSobrenomes = fopen("ListaDeSobrenomes.txt","r");
    FILE *arqUltimoNomes = fopen("ListaDeUltimosNomes.txt","r");
    FILE *arqCidadeEstadoRegiao = fopen("ListaDeCidades,Estados,Regioes.txt","r");

    if (arqNomes == NULL) {
        printf("Erro na abertura de arquivo de Nomes");
        return;
    } else {
        printf("Arquivo de Nomes Aberto com sucesso!\n");
    }

    if (arqSobrenomes == NULL) {
        printf("Erro na abertura de arquivo de Sobrenomes");
        return;
    } else {
        printf("Arquivo de Sobrenomes Aberto com sucesso!\n");
    }

    if (arqUltimoNomes == NULL) {
        printf("Erro na abertura de arquivoc de Ultimos Nomes");
        return;
    } else {
        printf("Arquivo de Ultimos nomes Aberto com sucesso!\n");
    }

    if (arqCidadeEstadoRegiao == NULL) {
        printf("Erro na abertura de arquivo de Cidades,estados e regioes");
        return;
    } else {
        printf("Arquivo de Cidades Aberto com sucesso!\n");
    }
    printf("\nValores Gerados Aleatoriamente:\n");
    printf("\n\n");

    //salva condicao inicial no arquivo:
    for(int init=0;init<NUMESCOLHAS;init++) {

        if(VetorDeEscolhas[init]!=0) {
            
            switch (VetorDeEscolhas[init]) {
                case 1:
                    printf("Nome");
                    fprintf(ArqDadosAleatorios,"Nome");
                    break;
                case 2:
                    printf("Nome e Sobrenome");
                    fprintf(ArqDadosAleatorios,"Nome e Sobrenome");
                    break;
                case 3:
                    printf("Nome Completo");
                    fprintf(ArqDadosAleatorios,"Nome Completo");
                    break;
                case 4:
                    printf("Telefone");
                    fprintf(ArqDadosAleatorios,"Telefone");
                    break;
                case 5:
                    printf("Data de Nascimento");
                    fprintf(ArqDadosAleatorios,"Data de Nascimento");
                    break;
                case 6:
                    printf("Idade");
                    fprintf(ArqDadosAleatorios,"Idade");
                    break;
                case 7:
                    printf("CPF");
                    fprintf(ArqDadosAleatorios,"CPF");
                    break;
                case 8:
                    printf("Numeros Aleatorios");
                    fprintf(ArqDadosAleatorios,"Numeros Aleatorios");
                    break;
                case 9:
                    printf("Cidades");
                    fprintf(ArqDadosAleatorios,"Cidades");
                    break;
                case 10:
                    printf("Estados");
                    fprintf(ArqDadosAleatorios,"Estados");
                    break;
                case 11:
                    printf("Regioes");
                    fprintf(ArqDadosAleatorios,"Regioes");
                    break;
                case 12:
                    printf("Cidades;Estados");
                    fprintf(ArqDadosAleatorios,"Cidades;Estados");
                    break;
                case 13:
                    printf("Cidade;Estado;Regioes");
                    fprintf(ArqDadosAleatorios,"Cidade; Estado ; Regioes");
                    break;
                case 14:
                    printf("Data De Nascimento;Idade");
                    fprintf(ArqDadosAleatorios,"Data De Nascimento;Idade");
                    break;
                default:
                    break;
            }
            printf(";");
            fprintf(ArqDadosAleatorios,";");
        }
    }
    fprintf(ArqDadosAleatorios,"\n");
    printf("\n");
    
    
    int *cpf = NULL;
    int contador = 1;
    for(int w=0;w<quantidade;w++) {
        for(int i = 0; i<NUMESCOLHAS;i++){
            if(VetorDeEscolhas[i]!=0) {
                switch (VetorDeEscolhas[i]) {
                
                    case 1: //Nome
                        escolheAleatorioArquivo(arqNomes,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 2: //Nome e Sobrenome
                        escolheAleatorioArquivo(arqNomes,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        fprintf(ArqDadosAleatorios, " ");
                        printf(" ");
                        escolheAleatorioArquivo(arqSobrenomes,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 3: //Nome Completo
                        escolheAleatorioArquivo(arqNomes,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        fprintf(ArqDadosAleatorios, " ");
                        printf(" ");
                        escolheAleatorioArquivo(arqSobrenomes,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        fprintf(ArqDadosAleatorios, " ");
                        printf(" ");
                        escolheAleatorioArquivo(arqUltimoNomes,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 4: //Telefone
                        TelefoneAleatorio(ArqDadosAleatorios);
                        break;
                    case 5: //Data de Nascimento
                        dataDeNascimentoAleatoria(ArqDadosAleatorios,VetorDeEscolhas[i]);
                        break;
                    case 6: //idade
                        aux = w;
                        int *numero = NumeroRandom(1,100);
                        if(aux>=100 && aux<10000) {
                            aux = aux % 100;
                        } else  {
                            if(aux>=10000) {
                                //printf("entrou em >10000");
                                aux = aux % 10000;
                                if(aux>=100){
                                    aux = aux % 100;
                                }
                            }
                        }
                        if(numero[aux]==0){
                            aux = 2;
                        }
                        fprintf(ArqDadosAleatorios, "%d",numero[aux]);
                        printf("%d",numero[aux]);
                        break;
                    case 7: //CPF
                        cpf = cpf_generator();
                        for(int lacoCPF = 0; lacoCPF < 11; lacoCPF++) {
                            printf("%d", cpf[lacoCPF]);
                            fprintf(ArqDadosAleatorios,"%d",cpf[lacoCPF]);
                        }
                        free(cpf);
                        break;
                    case 8: //Numeros Aleatorios
                        contador = NumerosAleatorios(ArqDadosAleatorios,VetorDeEscolhas[i],VetorNumAleatorios,contador,w);
                        break;
                    case 9: //Cidades
                        escolheAleatorioArquivo(arqCidadeEstadoRegiao,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 10: //Estados
                        escolheAleatorioArquivo(arqCidadeEstadoRegiao,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 11: //Regioes
                        escolheAleatorioArquivo(arqCidadeEstadoRegiao,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 12: //Cidades e Estados
                        escolheAleatorioArquivo(arqCidadeEstadoRegiao,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 13: //Cidade, Estado e Regioes
                        escolheAleatorioArquivo(arqCidadeEstadoRegiao,ArqDadosAleatorios,VetorDeEscolhas[i],w);
                        break;
                    case 14: //Data de Nascimento e Idade
                        dataDeNascimentoAleatoria(ArqDadosAleatorios,VetorDeEscolhas[i]);
                        break;
                    default:
                        break;
                }
           
            } else {
                break;
            }

            fprintf(ArqDadosAleatorios, ";"); 
            printf(";");

        }
        contador = 1;
        fprintf(ArqDadosAleatorios, "\n"); //isso eu tenho que salvar no arquivo.
        printf("\n"); 
    }
    
    /*
    printf("Vetor de Escolhas:\n");
    for(int i=0;i<NUMESCOLHAS;i++) {
        printf("%d ",VetorDeEscolhas[i]);
    }

    printf("Vetor de NumAleatorios: ");
    for(int i=0;i<TamvectAleatorios;i++) {
        printf("%d ",VetorNumAleatorios[i]);
    }
    */

    fclose(arqNomes);
    fclose(arqSobrenomes);
    fclose(arqUltimoNomes);
    fclose(arqCidadeEstadoRegiao);
    fclose(ArqDadosAleatorios);
    
    printf("\n\n");
    printf("Operacao Encerrada");

}

void TelefoneAleatorio(FILE * ArquivoSalmento){
    int ddd;
    int numeroPart1;
    int numeroPart2;
    ddd = 10 + rand() % 89 + 0001;

    int vetDDDInexistentes[40] = {20,23,25,26,29,30,39,40,50,52,56,57,58,59,60,70,72,76,78,80,90};

    //apenas para diminuir a probabilidade de cair DDD's inexistentes.
    for(int dvet=0;dvet<40;dvet++){
        if(ddd==vetDDDInexistentes[dvet]){
            ddd = 10 + rand() % 89 + 0001;
            dvet = 0;
        }
    }

    //mais uma verificacao para reduzir ainda mais essa probabilidade.
    for(int dvet=0;dvet<40;dvet++){
        if(ddd==vetDDDInexistentes[dvet]){
            ddd = 10 + rand() % 89 + 0001;
            dvet = 0;
        }
    }
    
    numeroPart1 = rand() % 9999;
    numeroPart2 = rand() % 9999;
    //printf("telefone gerado:");
    printf("(%d) 9%04d-%04d",ddd,numeroPart1,numeroPart2);
    fprintf(ArquivoSalmento,"(%d) 9%04d-%04d",ddd,numeroPart1,numeroPart2);
}

void dataDeNascimentoAleatoria(FILE * ArquivoSalmento, int op){
    int dia,mes,ano;
    dia = rand() % 30 + 0001;
    mes = rand() % 12 + 0001;
    //gerando datas aleatorias de 1950 até 2010.
    //caso queira alterar, basta colocar: (ano de inicio) - (ano de fim)
    //exemplo: 2010 - 1950 = 60 --> 60 é o valor passado para rand().
    ano = rand() % 60 + 1927;
    //printf("Data gerada:");
    printf("%02d/%02d/%d",dia,mes,ano);
    fprintf(ArquivoSalmento,"%02d/%02d/%d",dia,mes,ano);

    if(op==14) {
        int idade = anoAtual();
        idade = idade - ano;
        printf(";");
        fprintf(ArquivoSalmento,";");
        printf("%d",idade);
        fprintf(ArquivoSalmento,"%d",idade);
    }
}

int* cpf_generator() {
    int *cpf, pesos[11], vetSoma[11], soma, resto, digito,  i;
     
    // Aloca memória para o cpf
    cpf = (int *) malloc(sizeof(int) * 11);
     
    // Gera 9 números aleatórios
    for(i = 0; i < 9; i++) {
        cpf[i] = rand() % 10;
    }
     
    // Cálculo do primeiro dígito verificador
     
    // Gera os 9 pesos
    for(i = 0; i < 9; i++) {
        pesos[i] = 10 - i;
    }
     
    // Multiplica os valores de cada coluna
    for(i = 0; i < 9; i++) {
        vetSoma[i] = cpf[i] * pesos[i];
    }
     
    // Calcula o somatório dos resultados
    soma = 0;
    for(i = 0; i < 9; i++) {
        soma += vetSoma[i];
    }
     
    // Realiza-se a divisão inteira do resultado por 11
    resto = soma % 11;
     
    // Verifica o resto da divisão
    if(resto < 2) {
        digito = 0;
    } else {
        digito = 11 - resto;
    }
     
    // Adiciona o 1º dígito verificador ao cpf
    cpf[9] = digito;
     
    // Cálculo do segundo dígito verificador
     
    // Gera os 10 pesos
    for(i = 0; i < 10; i++) {
        pesos[i] = 11 - i;
    }
     
    // Multiplica os valores de cada coluna
    for(i = 0; i < 10; i++) {
        vetSoma[i] = cpf[i] * pesos[i];
    }
     
    // Calcula o somatório dos resultados
    soma = 0;
    for(i = 0; i < 10; i++) {
        soma += vetSoma[i];
    }
     
    // Realiza-se a divisão inteira do resultado por 11
    resto = soma % 11;
     
    // Verifica o resto da divisão
    if(resto < 2) {
        digito = 0;
    } else {
        digito = 11 - resto;
    }
     
    // Adiciona o 2º dígito verificador ao cpf
    cpf[10] = digito;
     
    return cpf;
}



int NumerosAleatorios(FILE *arquiSalvamento,int opcao,int VetorNumAleatorios[],int contador,int w) {

    fflush(stdin);
    int CasaDecimal,min,max;
    int decimal;

    CasaDecimal = VetorNumAleatorios[contador-1];
    min = VetorNumAleatorios[contador];
    max = VetorNumAleatorios[contador+1];

    contador = contador + 3;
    
    int *numRandom = NumeroRandom(min,max);

    if(w>=max) {
        w = w % (max-1);
    }
    if(numRandom[(w+1)]<=0){
        w = 1;
    }

    int inteiro;
    
    switch (CasaDecimal)
    {
    case 1: //Uma casa decimal
        decimal = rand() % 10;
        if(numRandom[(w+1)]<=0 || numRandom[(w+1)]>=1000){
            inteiro = min + rand() % (max+1);
            printf("%d,%d",inteiro,decimal);
            fprintf(arquiSalvamento,"%d,%d",inteiro,decimal);
            free(numRandom);
            return contador;
        }
        printf("%d,%d",numRandom[(w+1)],decimal);
        fprintf(arquiSalvamento,"%d,%d",numRandom[(w+1)],decimal);
        break;

    case 2:  //Duas Casas decimais
        decimal = rand() % 100;
        if(numRandom[(w+1)]<=0 || numRandom[(w+1)]>=1000){
            inteiro = min + rand() % (max+1);
            printf("%d,%02d",inteiro,decimal);
            fprintf(arquiSalvamento,"%d,%02d",inteiro,decimal);
            free(numRandom);
            return contador;
        }
        printf("%d,%02d",numRandom[(w+1)],decimal);
        fprintf(arquiSalvamento,"%d,%02d",numRandom[(w+1)],decimal);
        break;

    case 3: //Nao tera casa decimal.
        if(numRandom[(w+1)]<=0 || numRandom[(w+1)]>=1000){
            inteiro = min + rand() % (max+1);
            printf("%d",inteiro);
            fprintf(arquiSalvamento,"%d",inteiro,decimal);
            free(numRandom);
            return contador;
        }
        printf("%d",numRandom[(w+1)]);
        fprintf(arquiSalvamento,"%d",numRandom[(w+1)]);
        break;

    default:
        break;
    }
    
    return contador;
}

//char * CidEstadoRegiao(char Frase[100],int op);


void escolheAleatorioArquivo(FILE *arquivo,FILE *arquivoSalvamento, int opcao,int valor) {
    
    char linhadescarte[100];
    char linha[100];
    int tamanhoArq,tamPrimeiraLinha,PosUltimaLinhaArq;

    fseek(arquivo,0,SEEK_SET);
    
    fgets(linhadescarte,sizeof(linhadescarte),arquivo);
    tamPrimeiraLinha = ftell(arquivo);
    PosUltimaLinhaArq = tamPrimeiraLinha;
    int i=1;
    while(fgets(linhadescarte,sizeof(linhadescarte),arquivo)){
        i++;
        tamanhoArq = ftell(arquivo);

        if(fgets(linhadescarte,sizeof(linhadescarte),arquivo)){
            PosUltimaLinhaArq = tamanhoArq;
        } else {
            break;
        }
        fseek(arquivo,tamanhoArq,SEEK_SET); //retorna a posicao corrente
        //printf("Tamanho Procura Final: %d\n",PosUltimaLinhaArq);        
    }


    int *numRandom = NumeroRandom(0,tamanhoArq);

    //int *a = NumeroRandom2(1,tamanhoArq);
    //printf("Numero aleatorio gerado: %d\n",numRandom[0]);
    
    if(numRandom[opcao*(valor+1)]>=PosUltimaLinhaArq) { //é o ultimo? entao salva a ultima linha.

        fseek(arquivo,PosUltimaLinhaArq,SEEK_SET);
        fgets(linha,sizeof(linha),arquivo);
        linha[strcspn(linha,"\n")]= 0;

        if(opcao>=9 && opcao<=13) { //apenas para cid, est e regiao.
            char *linha2 = CidEstadoRegiao(linha,opcao);
            //printf("\n\tString retornada: %s\n",linha);
            free(linha2);
            //strcpy(linha,FraseArquivo);
        }

        
        fprintf(arquivoSalvamento, "%s",linha);
        printf("%s",linha);
        //return
    } else {
        fseek(arquivo,numRandom[opcao*(valor+1)],SEEK_SET); //se nao, descarte essa linha e salve a prox
        fgets(linhadescarte,sizeof(linhadescarte),arquivo);
        fgets(linha,sizeof(linha),arquivo);
        linha[strcspn(linha,"\n")]= 0;

        if(opcao>=9 && opcao<=13) { //apenas para cid, est e regiao.
            char *linha2 = CidEstadoRegiao(linha,opcao);
            //printf("\n\tString retornada: %s\n",linha);
            free(linha2);
            //strcpy(linha,FraseArquivo);
        }

        printf("%s",linha);
        fprintf(arquivoSalvamento, "%s",linha);
    }
    

}

char * CidEstadoRegiao(char Frase[100],int op) {
    //Frase[strcspn(Frase, "\n")] = 0;

    if(op == 13) {
        //printf("Sera salvo no arquivo:\n");
        //printf("%s",Frase);
        return Frase;
    }
    
    const char virgula[2] = ";";
    char *palavraQuebrada;
    palavraQuebrada = strtok(Frase, virgula);
    int cont = 0;

    char cidade[300];
    char estado[300],regiao[300];
    //char DataClienteStringAux[15];
    while( cont != 3 ) { //Lê até o final da linha
        
        if(cont == 0) { //cidade
            //strncpy( cidade, palavraQuebrada, 300 );
            strcpy(cidade,palavraQuebrada);
            //printf( "cidade:|%s|\n", cidade );
        }

        if(cont == 1) { //estado
            strcpy(estado,palavraQuebrada);
            //printf( "estado:|%s|\n", estado);
        }

        if(cont == 2) { //regiao
            strcpy(regiao,palavraQuebrada);
            //printf( "regiao:|%s|\n", regiao );
        }

        palavraQuebrada = strtok(NULL, virgula); //a cada iteracao uma parte da linha é quebrada

      cont++;

    }


    //printf("\nSwitch opcao: \n");
    switch (op) {
        case 9: //cidade
            //printf("op: %d - Cidade: %s",op,cidade);
            strcpy(Frase,cidade);
            return Frase;
            break;

        case 10: //estado
            //printf("op: %d - estado: %s",op,estado);
            strcpy(Frase,estado);
            return Frase;
            break;

        case 11: //regiao
            //printf("op: %d - regiao: %s",op,regiao);
            strcpy(Frase,regiao);
            return Frase;
            break;

        case 12: //cidade e estado
            strcat(cidade,virgula);
            strcat(cidade,estado);
            //printf("op: %d - Cidade: %s,Estado:%s",op,cidade,estado);
            strcpy(Frase,cidade);
            //printf("op: %d - Cidade e estado: %s",op,cidade);
            return Frase;
            break;
    }

}

int NumeroRandom(int min, int max){
    //srand(time(NULL));
    int * numeros = malloc((max - min) * sizeof(int));
    if (!numeros) exit(EXIT_FAILURE);
    for (int i = 0; i < max - min; i++) {
        numeros[i] = i + min;
    }
    shuffle(numeros,min,max);

    return numeros;
}

void shuffle(int *array,int min,int max) {
    for (int i = max - min - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int tmp = array[j];
        array[j] = array[i];
        array[i] = tmp;
    }
}

int confirmarAcao() {//Confirma se a pessoa quer continuar?
    int op;
    do{
        printf("Deseja continuar?\n");
        printf("[1] Sim \n");
        printf("[0] Nao\n");
        scanf("%d", &op);
    
    }while(op<0  || op >1);
    return op;
}

int main() {

    menuGerador();

    return 0;
}


int anoAtual() {

    int anoAtual;
    time_t data_ano;//Foi criada uma variável chamada data_ano que é do tipo time_t que é um tipo de variável que recebe valores de data e hora.
    time(&data_ano);
  
    struct tm *data = localtime(&data_ano);

    anoAtual = (data->tm_year+1900);    

    //printf("%d\n",anoAtual);
    return anoAtual;

}